1. main.py: run main to start front end web page, you can see the page with local ip in the browser.

2. FRE_server5.py: if you want to do the auto trading part, you should have it run on another console.

3. BBDModel.py: python code to build model, including functions like: stock selection, train model, etc.

4. BBD_client.py: client side of the trading. Send out different requests to the server side.

5. ClientFrontEnd.py: Flask design

6. static and templates: html files for Flask.